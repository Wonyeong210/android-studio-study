# 06 Navigation Menu 커스텀

왼쪽에서 오른쪽으로 화면을 슬라이드 했을 때 메뉴가 열리는 것을 기본으로 제공하는 템플릿이 아닌 커스텀을 해서 구성하는 프로젝트이다. 마음대로 커스텀할 수 있어서 좋다.

## 결과

![06%20Navigation%20Menu%20%E1%84%8F%E1%85%A5%E1%84%89%E1%85%B3%E1%84%90%E1%85%A5%E1%86%B7%20a9eeb26b710c45358e43d604affcd5d9/Untitled.png](06%20Navigation%20Menu%20%E1%84%8F%E1%85%A5%E1%84%89%E1%85%B3%E1%84%90%E1%85%A5%E1%86%B7%20a9eeb26b710c45358e43d604affcd5d9/Untitled.png)

![06%20Navigation%20Menu%20%E1%84%8F%E1%85%A5%E1%84%89%E1%85%B3%E1%84%90%E1%85%A5%E1%86%B7%20a9eeb26b710c45358e43d604affcd5d9/Untitled%201.png](06%20Navigation%20Menu%20%E1%84%8F%E1%85%A5%E1%84%89%E1%85%B3%E1%84%90%E1%85%A5%E1%86%B7%20a9eeb26b710c45358e43d604affcd5d9/Untitled%201.png)

Open 버튼 (btn_open)을 누르면 네비게이션 바가 왼쪽에서 나오고 Close Menu 버튼 (btn_close)를 누르면 네비게이션 바가 닫힌다.

### 1. 새로운 activity_drawer.xml을 생성한다.

![06%20Navigation%20Menu%20%E1%84%8F%E1%85%A5%E1%84%89%E1%85%B3%E1%84%90%E1%85%A5%E1%86%B7%20a9eeb26b710c45358e43d604affcd5d9/Untitled%202.png](06%20Navigation%20Menu%20%E1%84%8F%E1%85%A5%E1%84%89%E1%85%B3%E1%84%90%E1%85%A5%E1%86%B7%20a9eeb26b710c45358e43d604affcd5d9/Untitled%202.png)

![06%20Navigation%20Menu%20%E1%84%8F%E1%85%A5%E1%84%89%E1%85%B3%E1%84%90%E1%85%A5%E1%86%B7%20a9eeb26b710c45358e43d604affcd5d9/Untitled%203.png](06%20Navigation%20Menu%20%E1%84%8F%E1%85%A5%E1%84%89%E1%85%B3%E1%84%90%E1%85%A5%E1%86%B7%20a9eeb26b710c45358e43d604affcd5d9/Untitled%203.png)

### 2. activity_drawer.xml에 네비 메뉴가 열렸을 때 나오는 화면을 구성해주면 된다.

![06%20Navigation%20Menu%20%E1%84%8F%E1%85%A5%E1%84%89%E1%85%B3%E1%84%90%E1%85%A5%E1%86%B7%20a9eeb26b710c45358e43d604affcd5d9/Untitled%204.png](06%20Navigation%20Menu%20%E1%84%8F%E1%85%A5%E1%84%89%E1%85%B3%E1%84%90%E1%85%A5%E1%86%B7%20a9eeb26b710c45358e43d604affcd5d9/Untitled%204.png)

### 3. MainActivity.java에서 네비게이션 바가 열리고 닫히도록 코드를 작성한다.

```java
package com.example.customnaviexample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private View drawerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // activity_main.xml에 있는 DrawerLayout 요소
        drawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        // activity_drawer.xml에 있는 LineaerLayout 요소
        drawerView = (View)findViewById(R.id.drawer);

        // btn_open
        Button btn_open = (Button)findViewById(R.id.btn_open);
        btn_open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(drawerView);
            }
        });
        drawerLayout.setDrawerListener(listener);
        drawerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });

        // btn_close
        Button btn_close = (Button)findViewById(R.id.btn_close);
        btn_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.closeDrawers();
            }
        });
        drawerLayout.setDrawerListener(listener);
        drawerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });

    }

    // 나중에 커스텀할 때 사용할 수 있는 메소드들
    DrawerLayout.DrawerListener listener = new DrawerLayout.DrawerListener() {
        @Override
        public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {

        }

        @Override
        public void onDrawerOpened(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerClosed(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerStateChanged(int newState) {

        }
    };

}
```

### activity_main.xml 코드

```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.drawerlayout.widget.DrawerLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:id="@+id/drawer_layout"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".MainActivity">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="match_parent">

        <Button
            android:id="@+id/btn_open"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:text="Open"
            />

    </LinearLayout>

    <include layout="@layout/activity_drawer"/>

</androidx.drawerlayout.widget.DrawerLayout>
```

### activity_drawer.xml 코드

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/drawer"
    android:layout_width="240dp"
    android:layout_height="match_parent"
    android:layout_gravity="start"
    android:background="#85ADB7FF"
    android:orientation="vertical">

    <Button
        android:id="@+id/btn_close"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_margin="10dp"
        android:text="Close Menu"/>

    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="Menu Example"
        android:gravity="center"/>

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_margin="10dp"
        android:orientation="vertical"
        android:background="#223ffc">

        <TextView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:text="Test Menu"
            android:gravity="center"/>
    </LinearLayout>

</LinearLayout>
```